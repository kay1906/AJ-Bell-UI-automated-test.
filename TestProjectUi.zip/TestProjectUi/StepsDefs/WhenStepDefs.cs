﻿using OpenQA.Selenium;
using System.Linq;
using TechTalk.SpecFlow;
using TestProjectUi.PageObjects;

namespace TestProjectUi.StepsDefs
{
    [Binding]
    public class WhenStepDefs : BasePage
    {
        public WhenStepDefs(IWebDriver driver)
        {
            Driver = driver;
        }

        [When(@"I choose to select I AM A FINANCIAL PROFESSIONAL option")]
        public void WhenIChooseToSelectIAMAFINANCIALPROFESSIONALOption()
        {
            CurrentPage<HomePage>().AdviserGateway.Click();
        }

        [When(@"I choose to select the FIND OUT MORE option")]
        public void WhenIChooseToSelectTheFINDOUTMOREOption()
        {
            CurrentPage<HomePage>().NavigateToRetirementInvestmentAccount();
        }

        [When(@"I choose to select CHARGES option gadget")]
        public void WhenIChooseToSelectCHARGESOptionGadget()
        {
            CurrentPage<RetirementInvestmentAccountPage>().ChargesLink.Click();
        }

        [When(@"I choose to download Charges – SIPP, ISA or GIA")]
        public void WhenIChooseToDownloadChargesSIPPISAOrGIA()
        {
            CurrentPage<ChargesPage>().ChargesSippIsaOrGiaLink.Click();
            Driver.SwitchTo().Window(Driver.WindowHandles.Last());
        }

        [When(@"I choose to REGISTER")]
        public void WhenIChooseToREGISTER()
        {
            CurrentPage<HomePage>().RegisterLink.Click();
        }

        [When(@"I choose to Continue")]
        public void WhenIChooseToContinue()
        {
            CurrentPage<RegisterPage>().ContinueBtn.Click();
        }

        [When(@"I choose enter in '(.*)' number in the FCA firm reference field")]
        public void WhenIChooseEnterInNumberInTheFCAFirmReferenceField(string fcaNumber)
        {
            CurrentPage<RegisterPage>().FcaNumberField.SendKeys(fcaNumber);
        }
    }
}
