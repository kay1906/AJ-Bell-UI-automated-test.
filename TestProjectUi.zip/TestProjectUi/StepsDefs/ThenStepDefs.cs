﻿using NUnit.Framework;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
using TestProjectUi.PageObjects;

namespace TestProjectUi.StepsDefs
{
    [Binding]
    public class ThenStepDefs : BasePage
    {
        public ThenStepDefs(IWebDriver driver)
        {
            Driver = driver;
        }

        [Then(@"I should see the Charges – SIPP, ISA or GIA product details displayed on a new window")]
        public void ThenIShouldSeeTheChargesSIPPISAOrGIAProductDetailsDisplayedOnANewWindow()
        {
            var actualUrlForPDF = Driver.Url;
            var expectedUrlForPDF = "https://www.investcentre.co.uk/sites/default/files/AJBIC_charges_and_rates.pdf";
            Assert.AreEqual(expectedUrlForPDF, actualUrlForPDF);
        }

        [Then(@"I should see '(.*)' page displayed")]
        public void ThenIShouldSeePageDisplayed(string expectedHeaderTxt)
        {
            var actualHeaderTxt = CurrentPage<RegisterPage>().RegisterPageHeader.Text;
            Assert.AreEqual(expectedHeaderTxt, actualHeaderTxt);
        }

        [Then(@"I should error message '(.*)' displayed")]
        public void ThenIShouldErrorMessageDisplayed(string expectedErrorMessageTxt)
        {
            var actualErrorMessageTxt = CurrentPage<RegisterPage>().ValidationErrorField.Text;
            Assert.AreEqual(expectedErrorMessageTxt, actualErrorMessageTxt);
        }
    }
}
