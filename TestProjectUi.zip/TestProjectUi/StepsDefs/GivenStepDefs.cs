﻿using OpenQA.Selenium;
using System.Threading;
using TechTalk.SpecFlow;
using TestProjectUi.PageObjects;
using TestProjectUi.UtilityHelpers;

namespace TestProjectUi.StepsDefs
{
    [Binding]
    public sealed class GivenStepDefs : BasePage
    {
        public GivenStepDefs(IWebDriver driver)
        {
            Driver = driver;
        }

        [Given(@"I navigate to investcentre site")]
        public void GivenINavigateToInvestCentreSite()
        {
            Driver.Navigate().GoToUrl(ConfigManager.WebSiteUrl);
        }
    }
}
