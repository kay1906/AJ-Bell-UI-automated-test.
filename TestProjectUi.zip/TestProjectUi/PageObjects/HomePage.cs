﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestProjectUi.PageObjects
{
    public class HomePage : BasePage
    {
        public IWebElement AdviserGateway => Driver.FindElement(By.Id("gateway-adviser"));
        public IWebElement CustomerGateway => Driver.FindElement(By.Id("gateway-customer"));
        public IWebElement FindOutMoreLink => Driver.FindElement(By.LinkText("FIND OUT MORE"));
        public IWebElement RegisterLink => Driver.FindElement(By.LinkText("REGISTER"));


        public ChargesPage NavigateToRetirementInvestmentAccount()
        {
            FindOutMoreLink.Click();
            WaitUntilElementIsVisible(By.LinkText("CHARGES"));
            return new ChargesPage();
        }
    }
}
