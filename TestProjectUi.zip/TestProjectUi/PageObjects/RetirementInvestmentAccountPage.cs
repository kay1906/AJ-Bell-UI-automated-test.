﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestProjectUi.PageObjects
{
    public class RetirementInvestmentAccountPage : BasePage
    {
        public IWebElement ChargesLink => Driver.FindElement(By.LinkText("CHARGES"));
    }
}
