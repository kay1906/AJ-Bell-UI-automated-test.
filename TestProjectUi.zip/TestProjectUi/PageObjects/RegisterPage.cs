﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestProjectUi.PageObjects
{
    public class RegisterPage : BasePage
    {
        public IWebElement RegisterPageHeader => Driver.FindElement(By.CssSelector("h1"));
        public IWebElement ContinueBtn => Driver.FindElement(By.Id("AdviserRegsitration_Login"));
        public IWebElement ValidationErrorField => Driver.FindElement(By.CssSelector("[class='field-validation-error']"));
        public IWebElement FcaNumberField => Driver.FindElement(By.Id("FSRNumber_TextBox"));
    }
}
