﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Text;
using TestProjectUi.UtilityHelpers;

namespace TestProjectUi.PageObjects
{
    public class BasePage : DriverManager
    {
        /// <summary>
        /// Note that this class inherit from DriverManager class
        /// </summary>
        public T CurrentPage<T>() where T : BasePage, new()
        {
            var page = new T { Driver = Driver };
            return page;
        }
    }
}